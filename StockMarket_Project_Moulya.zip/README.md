# StockMarket Project

Placeholder README for StockMarket.