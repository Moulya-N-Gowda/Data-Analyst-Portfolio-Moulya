## Retail Power BI Report Spec

Layout and visuals description.